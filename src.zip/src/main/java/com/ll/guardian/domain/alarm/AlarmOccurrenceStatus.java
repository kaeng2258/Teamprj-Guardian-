package com.ll.guardian.domain.alarm;

public enum AlarmOccurrenceStatus {
    SCHEDULED,
    RINGING,
    TAKEN,
    LATE,
    SKIPPED,
    PROVIDER_NOTIFIED
}
