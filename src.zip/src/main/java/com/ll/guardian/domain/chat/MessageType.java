package com.ll.guardian.domain.chat;

public enum MessageType {
    TEXT,
    IMAGE,
    FILE,
    NOTICE,
    CALL_START,
    CALL_END
}
