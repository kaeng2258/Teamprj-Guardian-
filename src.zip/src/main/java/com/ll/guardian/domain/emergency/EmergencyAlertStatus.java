package com.ll.guardian.domain.emergency;

public enum EmergencyAlertStatus {
    PENDING,
    RECEIVED_BY_PROVIDER,
    ACKNOWLEDGED,
    RESOLVED
}
