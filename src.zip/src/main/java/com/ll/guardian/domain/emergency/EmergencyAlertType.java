package com.ll.guardian.domain.emergency;

public enum EmergencyAlertType {
    CLIENT_EMERGENCY,
    PROVIDER_REQUEST
}
