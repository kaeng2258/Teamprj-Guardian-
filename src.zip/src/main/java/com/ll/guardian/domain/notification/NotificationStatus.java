package com.ll.guardian.domain.notification;

public enum NotificationStatus {
    PENDING,
    SENT,
    FAILED,
    READ
}
