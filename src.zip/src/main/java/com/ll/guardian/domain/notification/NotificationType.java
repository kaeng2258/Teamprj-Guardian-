package com.ll.guardian.domain.notification;

public enum NotificationType {
    MED_REMINDER,
    EMERGENCY,
    CHAT,
    SYSTEM,
    CALL_REQUEST
}
