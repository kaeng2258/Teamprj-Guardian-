package com.ll.guardian.domain.notification.dto;

public record WebPushConfigResponse(boolean enabled, String publicKey) {}
