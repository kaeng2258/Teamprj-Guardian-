package com.ll.guardian.domain.user;

public enum UserRole {
    CLIENT,
    PROVIDER,
    ADMIN
}
