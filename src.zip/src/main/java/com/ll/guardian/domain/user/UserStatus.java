package com.ll.guardian.domain.user;

public enum UserStatus {
    WAITING_MATCH,
    ACTIVE,
    INACTIVE,
    SUSPENDED
}
