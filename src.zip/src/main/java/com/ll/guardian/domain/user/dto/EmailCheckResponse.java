package com.ll.guardian.domain.user.dto;

public record EmailCheckResponse(boolean available, String message) {}
