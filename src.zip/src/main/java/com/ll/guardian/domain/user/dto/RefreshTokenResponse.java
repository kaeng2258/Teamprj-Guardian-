package com.ll.guardian.domain.user.dto;

public record RefreshTokenResponse(String accessToken, String refreshToken) {}
