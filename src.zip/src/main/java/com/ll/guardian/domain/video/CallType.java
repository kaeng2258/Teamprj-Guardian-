package com.ll.guardian.domain.video;

public enum CallType {
    VIDEO,
    VOICE
}
