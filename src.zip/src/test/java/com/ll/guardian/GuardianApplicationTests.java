package com.ll.guardian;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class GuardianApplicationTests {

	@Test
	void contextLoads() {
	}

}
